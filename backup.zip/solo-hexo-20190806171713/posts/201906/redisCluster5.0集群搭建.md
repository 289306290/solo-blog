title: redisCluster 5.0 集群搭建
date: '2019-06-18 17:13:56'
updated: '2019-06-18 17:53:26'
tags: [redis]
permalink: /articles/2019/06/18/1560849236797.html
---
## 以下内容操作在阿里云centos服务器:

## 1.安装docker
`yum install docker`
## 2.拉取Redis镜像
`docker pull redis`
## 3.准备集群文件
`mkdir /home/redis-cluster`
## 4.在/home/redis-cluster目录下面新建Redis配置模板redis-cluster.tmpl内容如下:
```
port ${PORT}
protected-mode no
cluster-enabled yes
cluster-config-file nodes.conf
cluster-node-timeout 5000
cluster-announce-ip 39.10X.XX.XX //每个容器自己的IP(有了ip后再修改)
cluster-announce-port ${PORT}
cluster-announce-bus-port 1${PORT}
appendonly yes
```

## 5.容器直接采用的docker网络创建
```shell
docker network create redis-net
````
可以执行命令`docker network inspect redis-net`查看网络情况.
查看到网管地址后,下面每个容器的cluster-announce-ip 可以推断出来(不知道准不准)

## 6.在redis-cluster目录下面生成6个文件夹，从7000到7005，每个文件夹下包含data和conf文件夹，同时conf里面有redis.conf配置文件
```
for port in `seq 7000 7005`; do \
  mkdir -p ./${port}/conf \
  && PORT=${port} envsubst < ./redis-cluster.tmpl > ./${port}/conf/redis.conf \
  && mkdir -p ./${port}/data; \
done
```  
## 7.启动6个Redis容器,为了获取容器的ip地址.
```
for port in `seq 7000 7005`; do \
  docker run -d -ti -p ${port}:${port} -p 1${port}:1${port} \
  -v /home/redis-cluster/${port}/conf/redis.conf:/usr/local/etc/redis/redis.conf \
  -v /home/redis-cluster/${port}/data:/data \
  --restart always --name redis-${port} --net redis-net \
  --sysctl net.core.somaxconn=1024 redis redis-server /usr/local/etc/redis/redis.conf; \
done
```
## 8 查看容器的IP信息
`docker inspect --format '{{ (index .NetworkSettings.Networks "redis-net").IPAddress }}' "redis-7000"`
列出所有容器的IP信息以及端口,作为创建集群的参数（后面使用）
```
(for port in `seq 7000 7005`; do \
    echo -n "$(docker inspect --format '{{ (index .NetworkSettings.Networks "redis-net").IPAddress }}' "redis-${port}")":${port} ' ' ; \
  done)
```
## 9.停止并删除所有容器,
```
docker stop $(docker ps -q -a)
docker rm $(docker ps -q -a)
```
## 10. 修改/home/redis-cluster/700*/conf/redis.conf文件中cluster-announce-ip 为对应的真实ip地址
## 11. 删除/home/redis-cluster/700*/conf/data/下面的内容
## 12 重新执行第7步,启动6个容器.
## 13 进入某个容器创建集群
```
docker exec -it redis-7000 bash
redis-cli --cluster create 172.19.0.2:7000 172.19.0.3:7001 172.19.0.4:7002 172.19.0.5:7003 172.19.0.6:7004 172.19.0.7:7005 --cluster-replicas 1  
```
## 14创建密码
分别连接每个Redis容器设置密码:`redis-cli -p 7000`
```
  config set masterauth passwordstr
  config set requirepass passwordstr
  config rewrite
```
## 15连接集群
`redis-cli -p 7000 -c -a passwordstr`