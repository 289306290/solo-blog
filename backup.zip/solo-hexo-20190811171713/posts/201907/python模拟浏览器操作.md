title: python模拟浏览器操作
date: '2019-07-09 16:43:00'
updated: '2019-07-09 16:43:00'
tags: [python模拟浏览器操作]
permalink: /articles/2019/07/09/1562661780577.html
---
```
# -*- coding:utf-8 -*-

#模拟登录CAS系统，收集提示信息
import time,os,sys
from splinter import Browser
import threading
import requests
import json
#获取当前时间
time_now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#企业微信api
api = "http://xxxxx.com/api/pushMsg"
#电话接口及参数
cell_url = 'http://xxxxx.com/v1/project/addPhoneNum'
body = {"phone":[{"num":"1381xxxxx"},{"num":"156xxxx"}],"proId":"193","tenantCode":"YYJK"}
headers = {"Content-Type": "application/json;charset=UTF-8"}

#定义多线程 打电话功能
def phone():
    for i in range(2):
        requests.post(url=cell_url,data=json.dumps(body),headers=headers)
        time.sleep(60)
t1 = threading.Thread(target=phone)
#定义多线程 发错误信息到微信功能
def weixin():
        faild_info = {"msg":[time_now,'from 172.16.1.32',error_log,'xxx系统故障，请立即检查!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!']}
        for i in range(10):
            requests.get(api,params=faild_info)
            time.sleep(2)
t2 = threading.Thread(target=weixin)

#模拟登陆
def login():
    username = 'fffffff'
    passwd = 'xxxxxxxpwd'
    identifying_code = 'fdsafda'
    url = 'http://abc.def.com/puhui-cas'
    global error_log  #报错信息定义为全局变量

    try:
        browser = Browser()  #针对默认的firefox浏览器，chrome可能存在驱动及浏览器版本的兼容问题
        browser.visit(url)
        browser.find_by_css("ul.login-type > li[data-type='pwd']").click()
        browser.find_by_id('username').fill(username)
        browser.find_by_id('password').fill(passwd)
        browser.find_by_id('verifycode').fill(identifying_code)
        browser.find_by_css("button.btn").click()
        time.sleep(2)

    except (IOError,AttributeError,Exception),e:
        error_log =  str(e.msg)

    finally:
        if browser.is_text_present('登录成功')  or browser.is_text_present('立即修改'):
            success_info = {"msg":[time_now,'from 172.16.1.32','CAS服务正常']}
            requests.get(api,params=success_info)
        else :
            for t in [t1,t2]:
                t.start()
        browser.quit()

if __name__ == '__main__':
    login()


```