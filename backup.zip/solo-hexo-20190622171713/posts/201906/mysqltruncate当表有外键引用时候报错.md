title: mysql truncate 当表有外键引用时候,报错
date: '2019-06-18 19:03:47'
updated: '2019-06-18 19:03:47'
tags: [mysql]
permalink: /articles/2019/06/18/1560855827098.html
---
清空具有外键约束的表时报ERROR 1701(42000)的解决
 
   ERROR 1701 (42000): Cannot truncate a table referenced in a foreign keyconstraint (`furion`.`tbl_frn_alert`, CONSTRAINT `FK353A3CBEB139CC08`FOREIGN KEY (`endpt_id`) REFERENCES `furion`.`tbl_frn_endpt` (`id`))
  www.2cto.com  
解决方法：
 
 SET foreign_key_checks=0;
 
 删除后
 
mysql> SET foreign_key_checks=1;