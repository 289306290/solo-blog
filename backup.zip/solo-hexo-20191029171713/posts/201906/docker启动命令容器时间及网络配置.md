title: docker启动命令,容器时间及网络配置
date: '2019-06-18 19:10:47'
updated: '2019-06-18 19:10:47'
tags: [docker]
permalink: /articles/2019/06/18/1560856247279.html
---
1. docker容器时间:
总结：将宿主机的 /usr/share/zoneinfo/Asia/Shanghai 放到容器中的/etc/localtime 文件
或者:启动时候就挂在好：
 -v /usr/share/zoneinfo/Asia/Shanghai:/etc/localtime:ro

2. MAC上面docker之间互联
由于mac操作系统的限制，要想mac主机访问docker里面的内容
必须在启动容器的时候 制定 -p 8080:8080 这么指定。

容器之间互联可以搭建自己的网络环境

```
docker network ls 

docker network inspect my-bridge-network

docker network create -d bridge my-bridge-network

docker run -d --network=my-bridge-network --name db training/postgres

docker network connect my-bridge-network web  (将多个容器例如web添加到同一个网络中,之后可以通过Ip或者容器名称来直接访问)

但是如果启动的容器是用--net=host方式的话，则无法添加到上述自己创建的网络环境中

docker network disconnect bridge networktest
```
3.启动docker命令
   -i 交互式
   -t 终端
   -d 后台运行 结合command【/bin/bash】
   --name 容器名称
  --add-host db-static:86.75.30.9   添加host
  -h  主机名hostname
  -v 挂在主机目录到容器
  -p 端口映射
  --privileged=true 使容器拥有root权限(还不是很理解)
  --netwok 是容器接入提前建立好的网络my-gridge-network中
  daocloud.io/nginx  镜像地址:标签
  /bin/bash  command命令
```
docker run -itd --name=glusterServer1 -h glusterServer1
 -v /data/dockerVolumn:/data  --privileged=true  -p 8080:80 
 -p 1234:1234 --network=my-bridge-network  daocloud.io/nginx /bin/bash 
```