title: mac下面显示隐藏文件
date: '2019-06-18 19:09:31'
updated: '2019-06-18 19:09:31'
tags: [mac]
permalink: /articles/2019/06/18/1560856171858.html
---
显示隐藏文件
```
defaults write com.apple.finder AppleShowAllFiles -bool true
killall Finder  
```
不显示
```
defaults write com.apple.finder AppleShowAllFiles -bool false

killall Finder
```