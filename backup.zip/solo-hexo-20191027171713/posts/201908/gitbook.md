title: gitbook
date: '2019-08-22 17:59:37'
updated: '2019-08-22 18:31:38'
tags: [node]
permalink: /articles/2019/08/22/1566467977673.html
---
安装nodejs
下载地址:https://nodejs.org/en/download/

安装:

Linux 上安装 Node.js
-----------------

### 直接使用已编译好的包

Node 官网已经把 linux 下载版本更改为已编译好的版本了，我们可以直接下载解压后使用：

`# wget https://nodejs.org/dist/v10.9.0/node-v10.9.0-linux-x64.tar.xz    // 下载  # tar xf  node-v10.9.0-linux-x64.tar.xz       // 解压  # cd node-v10.9.0-linux-x64/                  // 进入解压目录  # ./bin/node -v                               // 执行node命令 查看版本 v10.9.0`

解压文件的 bin 目录底下包含了 node、npm 等命令，我们可以使用 ln 命令来设置软连接：

`ln -s /usr/software/nodejs/bin/npm /usr/local/bin/ ln -s /usr/software/nodejs/bin/node /usr/local/bin/`

二:安装gitbook
`npm install gitbook-cli -g`

 ./gitbook -V  

book.json
{
    "title": "慧客知识库",
    "author": "hh",
    "description": "客服知识库",
    "language": "zh-hans",
    "gitbook": "3.2.3",
    "structure": {
        "readme": "README.md"
    },
    "links": {
        "sidebar": {
            "客服系统": "http://xx.ff.com"
        }
    },
    "plugins": [
        "-sharing",
        "splitter",
        "expandable-chapters-small",
        "anchors",
"-github-buttons",

        "-donate",
        "sharing-plus",
        "anchor-navigation-ex",
        "favicon",
 "-lunr","-search","search-pro",
        "back-to-top-button",
        "chapter-fold",
        "code"
    ]
 }