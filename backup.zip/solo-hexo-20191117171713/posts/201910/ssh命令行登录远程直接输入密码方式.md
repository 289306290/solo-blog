title: ssh命令行登录远程(直接输入密码方式)
date: '2019-10-30 11:16:16'
updated: '2019-10-30 11:16:16'
tags: [linux]
permalink: /articles/2019/10/30/1572405376183.html
---
先安装sshpass命令
https://www.jianshu.com/p/2ce1bc682ac6
```