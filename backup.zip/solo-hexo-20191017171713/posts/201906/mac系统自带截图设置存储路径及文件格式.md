title: mac系统自带截图设置存储路径及文件格式
date: '2019-06-18 19:09:08'
updated: '2019-06-18 19:09:08'
tags: [mac]
permalink: /articles/2019/06/18/1560856148824.html
---
在终端执行
1.设置存储路径/Users/用户名/Documents/screenshot

```
defaults write com.apple.screencapture location 
/Users/用户名/Documents/screenshot 
```

2.设置存储图片格式为jpg
```
defaults write com.apple.screencapture type jpg 
```


3.杀掉进程重新开启系统截图等

```
killall SystemUIServer
```