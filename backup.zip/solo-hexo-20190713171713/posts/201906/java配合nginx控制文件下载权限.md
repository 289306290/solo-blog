title: java配合nginx控制文件下载权限
date: '2019-06-18 19:07:07'
updated: '2019-06-18 19:07:07'
tags: [java]
permalink: /articles/2019/06/18/1560856027761.html
---
#使用下载地址
http://xxx.xxx.xxx/javadown/3214
```
location /javadown {
      internal;
      alias /home/datastore/coopDevelopment_online/upload;
      # 回调后台代理
      error_page 404 =200 @backend; 
 }
location @backend {
    #配置rewrite 跳到后台程序
     rewrite ^/javadown/(.*)$  /cooldev/resource/abc/$1 break; 
     proxy_pass http://192.168.2.165:8080;
     break; 
}
```

#java代码
```
@ResponseBody
@RequestMapping(value="/abc/{resourceId}", method=RequestMethod.GET)
	public Map<String, Object> abc(@PathVariable(value="resourceId") Long resourceId,
			HttpServletResponse response,@RequestHeader(value="loginUserId") long loginUserId) {
		try {
			log.info("========>abc:"+resourceId);
			log.info("========>loginUserId:"+loginUserId);
			Resource res = resourcesService.findOne(resourceId);
			if(null==res){
				return this.getFailedMap("请求的资源不存在");
			}
			String projectId = "/936/";
			response.setHeader("Content-Disposition", "attachment; filename="+res.getName());
			response.setHeader("Content-Type","application/octet-stream");
			response.setHeader("X-Accel-Redirect","/javadown"+projectId+res.getName());
			log.info("=======>资源下载路径："+"/javadown"+projectId+res.getName());
			return this.getSuccessMap(projectId+res.getName());
		} catch (Exception e) {
			e.printStackTrace();
			return this.getFailedMap(e.getMessage());
		}
	}
```
