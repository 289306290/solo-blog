title: mac调用命令释放内存
date: '2019-06-18 19:10:01'
updated: '2019-06-18 19:10:01'
tags: [mac]
permalink: /articles/2019/06/18/1560856201882.html
---
```
sudo purge
```