title: hashCode() 和 equals() 方法 浅谈
date: '2019-06-22 23:10:02'
updated: '2019-06-22 23:11:22'
tags: [java]
permalink: /articles/2019/06/22/1561216202718.html
---
```
public class Student {
    private String name;
    private int age;
    //省略getter, setter 方法

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Student student = (Student) o;

        return name.equals(student.getName()) && age == student.getAge();
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

}
```
##### 如果一个类,不往HashSet,HashMap,HashTable 等散列表中存放,那么其实hashCode()方法，没必要重写，甚至可以说有没有hashCode()方法根本没有关系。

什么时候会用到重写hashCode()方法，当对象需要存储到HashSet,HashMap,HashTable等散列表中的时候。比如代码如下:
```
public static void main(String[] args) {
        Student stu1 = new Student("张三", 18);
        Student stu2 = new Student("张三", 18);
        Student stu3 = new Student("张三", 20);
        Student stu4 = new Student("李四", 20);

        HashSet<Student> studentHashSet = new HashSet<>();
        studentHashSet.add(stu1);
        studentHashSet.add(stu2);
        //如果未重写Student对象的hashCode()方法,studentHashSet集合中有两个元素。
        System.out.println(studentHashSet.size());
        studentHashSet.stream().forEach(System.out::println);

    }
```
输出结果为:
```
2
Student{name='张三', age=18}
Student{name='张三', age=18}
```
而当重写Student中hashCode()方法后
```
 @Override
    public int hashCode() {
        int nameHashVal = name.toUpperCase().hashCode();
        return nameHashVal ^ age;
    }
```
重新执行上面main方法输出结果为
```
1
Student{name='张三', age=18}
```
以下内容转自  https://mp.weixin.qq.com/s/kiYM-dI3FCoMfBtbDbyVLg
**为什么HashSet会用到hashCode()呢？**
查看HashSet的源码部分

```
/**
 * HashSet部分
 */
public boolean add(E e) {
        return map.put(e, PRESENT)==null;
}


/**
 * map.put方法部分
 */
public V put(K key, V value) {
        return putVal(hash(key), key, value, false, true);
}

/**
 * putVal方法部分
 */
final V putVal(int hash, K key, V value, boolean onlyIfAbsent,
                   boolean evict) {
    Node<K,V>[] tab; Node<K,V> p; int n, i;
    if ((tab = table) == null || (n = tab.length) == 0)
        n = (tab = resize()).length;
    if ((p = tab[i = (n - 1) & hash]) == null)
        tab[i] = newNode(hash, key, value, null);
    else {
        Node<K,V> e; K k;
        if (p.hash == hash &&
            ((k = p.key) == key || (key != null && key.equals(k))))
            e = p;
        else if (p instanceof TreeNode)
            e = ((TreeNode<K,V>)p).putTreeVal(this, tab, hash, key, value);
        else {
            for (int binCount = 0; ; ++binCount) {
                if ((e = p.next) == null) {
                    p.next = newNode(hash, key, value, null);
                    if (binCount >= TREEIFY_THRESHOLD - 1) // -1 for 1st
                        treeifyBin(tab, hash);
                    break;
                }
                if (e.hash == hash &&
                    ((k = e.key) == key || (key != null && key.equals(k))))
                    break;
                p = e;
            }
        }
        if (e != null) { // existing mapping for key
            V oldValue = e.value;
            if (!onlyIfAbsent || oldValue == null)
                e.value = value;
            afterNodeAccess(e);
            return oldValue;
        }
    }
    ++modCount;
    if (++size > threshold)
        resize();
    afterNodeInsertion(evict);
    return null;
}
``````
可以看出，hashSet使用的是hashMap的put方法，而hashMap的put方法，使用hashCode()用key作为参数计算出hash值，然后进行比较，如果相同，再通过equals()比较key值是否相同，如果相同，返回同一个对象。

所以，如果类使用再散列表的集合对象中，要判断两个对象是否相同，除了要覆盖equals()之外，也要覆盖hashCode()函数。否则，equals()无效。
### 有哪些覆写hashCode的诀窍
> 
一个好的hashCode的方法的目标：为不相等的对象产生不相等的散列码，同样的，相等的对象必须拥有相等的散列码。

1、把某个非零的常数值，比如17，保存在一个int型的result中；

2、对于每个关键域f（equals方法中设计到的每个域），作以下操作：

*   a.为该域计算int类型的散列码；
```
i.如果该域是boolean类型，则计算(f?1:0),
ii.如果该域是byte,char,short或者int类型,计算(int)f,
iii.如果是long类型，计算(int)(f^(f>>>32)).iv.如果是float类型，计算Float.floatToIntBits(f).v.如果是double类型，计算Double.doubleToLongBits(f),然后再计算long型的hash值
vi.如果是对象引用，则递归的调用域的hashCode，如果是更复杂的比较，则需要为这个域计算一个范式，然后针对范式调用hashCode，如果为null，返回0
vii. 如果是一个数组，则把每一个元素当成一个单独的域来处理。
```
* b.result = 31 * result + c;

3、返回result

4、编写单元测试验证有没有实现所有相等的实例都有相等的散列码。

给个简单的例子：
```
@Override
public int hashCode() { 
	int result = 17; 
	result = 31 * result + name.hashCode(); 
	return result;
}
```
这里再说下2.b中为什么采用`31*result + c`,乘法使hash值依赖于域的顺序，如果没有乘法那么所有顺序不同的字符串String对象都会有一样的hash值，而31是一个奇素数，如果是偶数，并且乘法溢出的话，信息会丢失，31有个很好的特性是`31*i ==(i<<5)-i`,即2的5次方减1，虚拟机会优化乘法操作为移位操作的。