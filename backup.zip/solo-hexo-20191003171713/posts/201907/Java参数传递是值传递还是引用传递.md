title: Java参数传递是值传递还是引用传递？
date: '2019-07-07 22:27:47'
updated: '2019-07-07 22:32:44'
tags: [java]
permalink: /articles/2019/07/07/1562509667922.html
---
```
package com.finup.phone.task.job;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("abc");
        setNull(list);
        System.out.println(list.get(1));
        setNew(list);
        System.out.println(list.size());
    }

    //Java 对象传值,并不是传引用, 所以第一行list.add()生效加入了bbb, 第二行设置为null,也不会影响调用者
    public static void setNull(List list) {
        list.add("bbb");
        list = null;
    }

    //调用此方法对调用者来说,没任何影响
    public static void setNew(List list) {
        list = new ArrayList();
        list.add("ccccc");
        list.add("eeeee");
	list.add("dddd");
    }
}

```

输出结果是:

bbb
2