title: html页面引入外部img图片，提示403的问题
date: '2019-09-06 16:57:13'
updated: '2019-09-06 16:57:57'
tags: [html]
permalink: /articles/2019/09/06/1567760233415.html
---
在header中加入
`<meta name="referrer" content="no-referrer">`