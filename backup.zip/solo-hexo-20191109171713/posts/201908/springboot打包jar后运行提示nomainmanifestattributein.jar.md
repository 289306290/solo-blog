title: springboot打包jar后,运行提示no main manifest attribute, in /.jar
date: '2019-08-30 18:38:39'
updated: '2019-08-30 18:38:53'
tags: [待分类]
permalink: /articles/2019/08/30/1567161519864.html
---
解决办法:
```
<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
            <version>${spring.boot.version}</version>
            <executions>
                <execution>
                    <goals>
                        <goal>repackage</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```