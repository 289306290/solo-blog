title: nc在两台机器上互传文件
date: '2019-06-18 19:14:51'
updated: '2019-06-18 19:14:51'
tags: [linux]
permalink: /articles/2019/06/18/1560856490942.html
---
环境 server1  源地址
server2  目标地址

1.安装nc,多数机器默认已经安装了。
apt-get install netcat

2.进入目标机器server2，启动监听

nc -l 12345 | tar xzvf -

3.在源地址上操作

tar cvzf -  /var/lib/msql     |    nc server2  12345 