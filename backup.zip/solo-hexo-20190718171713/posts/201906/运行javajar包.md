title: 运行java jar包
date: '2019-06-18 19:15:33'
updated: '2019-06-18 19:15:33'
tags: [linux]
permalink: /articles/2019/06/18/1560856533198.html
---
start.sh
#!/bin/sh
java -Xms1024m -Xmx1024m -jar xxxxx.jar --spring.profiles.active=test &
echo $! > /var/run/Test.pid


结束服务 shutdown.sh
#!/bin/sh
PID=$(cat /var/run/TestOTA.pid)
kill -9 $PID




linux中shell变量$#,$@,$0,$1,$2的含义解释: 
变量说明: 
$$ 
Shell本身的PID（ProcessID） 
$! 
Shell最后运行的后台Process的PID 
$? 
最后运行的命令的结束代码（返回值） 
$- 
使用Set命令设定的Flag一览 
$* 
所有参数列表。如"$*"用「"」括起来的情况、以"$1 $2 … $n"的形式输出所有参数。 
$@ 
所有参数列表。如"$@"用「"」括起来的情况、以"$1" "$2" … "$n" 的形式输出所有参数。 
$# 
添加到Shell的参数个数 
$0 
Shell本身的文件名 
$1～$n 
添加到Shell的各参数值。$1是第1参数、$2是第2参数…。 