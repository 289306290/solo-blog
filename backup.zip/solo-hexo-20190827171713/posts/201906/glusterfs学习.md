title: glusterfs学习
date: '2019-06-18 19:14:25'
updated: '2019-06-18 19:14:25'
tags: [glusterfs]
permalink: /articles/2019/06/18/1560856465310.html
---
1. 官网https://www.gluster.org/
2. 下载https://www.gluster.org/download/
3.  相关英文文档 http://gluster.readthedocs.io/en/latest/Quick-Start-Guide/Quickstart/

了解:
1.至少有两个节点(机器),并且两个机器构成局域网可以互联.
2.建议两块磁盘:一块用来装操作系统相关的东西,另一块用来做glusterFS存储
3.由于glusterFS会动态的往/var/lib/glusterd中写入配置,所以建议为/var/lib/glusterd设置单独的分区

官网(此处省去,回头再研究,估计是xfs性能会好)
Step 2 - Format and mount the bricks
(on both nodes): Note: These examples are going to assume the brick is going to reside on /dev/sdb1.

```
mkfs.xfs -i size=512 /dev/sdb1 
mkdir -p /data/brick1
echo '/dev/sdb1 /data/brick1 xfs defaults 1 2' >> /etc/fstab 
mount -a && mount
```
You should now see sdb1 mounted at /data/brick1

#开始安装
>1. 在两台机器上分别执行
```
yum install glusterfs-server (centos)      
apt-get install glusterfs-server(ubuntu)
```
然后启动
```
service glusterd start （systemctl start glusterd）
service glusterd status (systemctl status glusterd)
```
>2. 确认两台机器的host文件配置(保证通过主机名可以互通)
172.18.0.3      glusterServer1      (server2的/etc/hosts)
172.18.0.4      glusterServer2      (server1的/etc/hosts)
>3. 配置trusted pool
a.在glusterServer1上执行
```
gluster peer probe glusterServer2
```
b.在glusterServer2上执行
```
gluster peer probe glusterServer1
```
c.可以分别在两台机器上执行gluster peer status查看状态
>4. 创建glusterFS数据卷

1). 在两台机器上分别执行
            mkdir /data/brick1/gfs
2). 在其中任意一台上执行
 ```
gluster volume create gfs replica 2 glusterServer1:/data/brick1/gfs glusterServer2:/data/brick1/gfs  [force]

```
如果提示volume create: gfs: failed: The brick glusterServer1:/home/gfs is is being created in the root partition. It is recommended that you don't use the system's root partition for storage backend. Or use 'force' at the end of the command if you want to override this behavior.
是因为我们创建的brick在系统盘，这个在gluster的默认情况下是不允许的，生产环境下也尽可能的与系统盘分开，如果必须这样请使用force 。
可以通过gluster volume create help查看帮助
Usage: volume create <NEW-VOLNAME> [stripe <COUNT>] [replica <COUNT>] [disperse [<COUNT>]] [redundancy <COUNT>] [transport <tcp|rdma|tcp,rdma>] <NEW-BRICK>?<vg_name>... [force]
<NEW-VOLNAME>：volume的名称
stripe <COUNT>：条待卷
replica <COUNT>：复制卷
disperse：哈希卷  默认
redundancy：冗余卷
transport <tcp|rdma|tcp,rdma>：传输协议，默认是TCP
     3). 其中一台启动数据卷 gluster volume start
    4). 用命令`gluster volume info`查看状态
        Volume Name: gfs
        Type: Replicate  （代表每台机器会留有一份完整的数据拷贝）
        Volume ID: ed3a04e2-e2a7-46b6-9141-186551bb02e0
        Status: Created
        Number of Bricks: 1 x 2 = 2
        Transport-type: tcp
        Bricks:
        Brick1: glusterServer1:/data/brick1/gfs
        Brick2: glusterServer2:/data/brick1/gfs
    5). 如果启动失败则一般情况查看日志文件(两台都看一下,不一定是哪台上有日志)，
  目录一般情况是/var/log/glusterfs/etc-glusterfs-glusterd.vol.log
    6). 启动数据卷
     ``` gluster volume start gfs```
      在用gluster volume info 查看状态由created变为started

测试:
```
客户端
wget -P /etc/yum.repos.d  http://download.gluster.org/pub/gluster/glusterfs/LATEST/CentOS/glusterfs-epel.repo
 yum install  glusterfs 
yum install glusterfs-fuse

客户端挂在
mkdir -p /mnt/glfs
mount -t glusterfs -o rw glusterServer1:gfs /mnt/glfs/
```
挂在失败
查看日志/var/log/glusterfs/mnt-glfs.log
[2016-08-22 18:15:34.542812] I [MSGID: 100030] [glusterfsd.c:2301:main] 0-/usr/sbin/glusterfs: Started running /usr/sbin/glusterfs version 3.7.1 (args: /usr/sbin/glusterfs --volfile-server=glusterServer1 --volfile-id=gfs /mnt/glfs)
[2016-08-22 18:15:34.543427] E [mount.c:341:gf_fuse_mount] 0-glusterfs-fuse: cannot open /dev/fuse (Operation not permitted)
[2016-08-22 18:15:34.543456] E [MSGID: 101019] [xlator.c:428:xlator_init] 0-fuse: Initialization of volume 'fuse' failed, review your volfile again

重新安装yum install fuse再挂
注意：
以后数据在client去 创建修改,在server端只能查看,如果在server端去修改,会出现问题.

挂在的时候可能会提示
WARNING: getfattr not found, certain checks will be skipped..
上网查说需要安装attr
但是我发现attr已经安装了。（有知道的朋友可以告知一下为啥）.
>.
问题:在我尝试的过程中发现在docker容器中,如果启动容器的时候没有加参数--privileged=true则挂在失败,重新加此参数运行容器再挂在就可以了(前提是已经安装了glusterfs,glusterfs-fuse)
客户端重启自动挂在可以修改/etc/fstab文件
vi /etc/fstab
在这个文件的底部添加下面这行代码，这里使用 /mnt/glfs 作为挂载点，你可以把它替换成自己想要的地方。
```
glusterServer1:gfs   /mnt/glfs   glusterfs defaults,_netdev 0 0
```