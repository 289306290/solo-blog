title: mysql初始化root密码及远程访问授权
date: '2019-06-18 18:45:11'
updated: '2019-06-18 18:45:11'
tags: [mysql]
permalink: /articles/2019/06/18/1560854711587.html
---
1.  **初始化root密码**
```
update user set password=PASSWORD (‘root’) where User='root';
```

2.  **允许mysql远程访问,可以使用以下两种方式:**

 a .修改user表
  ```
   use mysql;
   update user set host ='%' where user ='root';
   select host,user from user;
 ```

  b 授权
```
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;
```